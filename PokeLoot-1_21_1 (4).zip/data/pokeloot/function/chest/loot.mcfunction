# Macro function. Inputs: id, uuid, table (mode rides along for messages).
# Rolls the table as the player, at their feet, and locks the drops to that player so nobody can steal them.
execute at @a[tag=pokeloot.looter,limit=1] run tag @e[type=item,distance=..5] add pokeloot.old
scoreboard players set #n pokeloot.data 0
$execute store result score #n pokeloot.data as @a[tag=pokeloot.looter,limit=1] at @s run loot spawn ~ ~ ~ loot $(table)
$execute as @a[tag=pokeloot.looter,limit=1] at @s as @e[type=item,distance=..5,tag=!pokeloot.old] run data merge entity @s {Owner:$(uuid),PickupDelay:10s}
tag @e[type=item,tag=pokeloot.old] remove pokeloot.old
execute if score #n pokeloot.data matches 0 run return run function pokeloot:chest/empty
$data modify storage pokeloot:db chests.c$(id).claimed append value {u:$(uuid)}
scoreboard players set #result pokeloot.data 1
function pokeloot:chest/success
