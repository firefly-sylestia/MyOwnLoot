# Runs as the loot chest hitbox, at the chest. The clicking player carries the tag pokeloot.looter.
# #result codes: 0 unset, 1 looted, 2 already looted, 3 empty roll, 4 not registered, 5 error
data remove entity @s interaction
data modify storage pokeloot:tmp args set value {}
scoreboard players set #result pokeloot.data 0
execute unless score @s pokeloot.id matches 0.. run return run function pokeloot:chest/missing
execute store result storage pokeloot:tmp args.id int 1 run scoreboard players get @s pokeloot.id
data modify storage pokeloot:tmp args.uuid set from entity @a[tag=pokeloot.looter,limit=1] UUID
function pokeloot:chest/check with storage pokeloot:tmp args
execute if score #result pokeloot.data matches 0 run function pokeloot:chest/error
execute as @a[tag=pokeloot.looter,tag=pokeloot.debug] run function pokeloot:chest/debug_msg
