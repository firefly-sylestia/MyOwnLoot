scoreboard players set #result pokeloot.data 2
playsound minecraft:block.chest.locked block @a[tag=pokeloot.looter] ~ ~ ~ 1 1
particle minecraft:smoke ~ ~1 ~ 0.25 0.25 0.25 0.01 8 normal @a[tag=pokeloot.looter]
title @a[tag=pokeloot.looter] actionbar {"text":"You already looted this chest.","color":"red"}
