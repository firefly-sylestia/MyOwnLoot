# Runs as a hitbox that has no registry entry. It is removed, so the block becomes a normal chest again.
scoreboard players set #result pokeloot.data 4
tellraw @a[tag=pokeloot.looter] {"text":"[PokeLoot] This chest is no longer registered, so it is a normal chest again.","color":"red"}
kill @s
