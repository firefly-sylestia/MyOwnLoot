# Runs as a player who has debug messages on.
tellraw @s ["",{"text":"[PokeLoot debug] ","color":"gray"},{"text":"chest #","color":"gray"},{"storage":"pokeloot:tmp","nbt":"args.id","color":"white"},{"text":"  mode: ","color":"gray"},{"storage":"pokeloot:tmp","nbt":"args.mode","color":"white"},{"text":"  table: ","color":"gray"},{"storage":"pokeloot:tmp","nbt":"args.table","color":"white"}]
execute if score #result pokeloot.data matches 1 run tellraw @s {"text":"  result: looted, items dropped at your feet, claim saved","color":"green"}
execute if score #result pokeloot.data matches 2 run tellraw @s {"text":"  result: already looted by this player","color":"red"}
execute if score #result pokeloot.data matches 3 run tellraw @s {"text":"  result: roll gave nothing, not counted as looted","color":"yellow"}
execute if score #result pokeloot.data matches 4 run tellraw @s {"text":"  result: chest was not in the registry, hitbox removed","color":"red"}
execute if score #result pokeloot.data matches 5 run tellraw @s {"text":"  result: error, check the loot table id","color":"red"}
