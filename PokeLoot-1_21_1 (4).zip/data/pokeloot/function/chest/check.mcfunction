# Macro function. Inputs: id, uuid.
$execute unless data storage pokeloot:db chests.c$(id) run return run function pokeloot:chest/missing
$data modify storage pokeloot:tmp args.table set from storage pokeloot:db chests.c$(id).table
$data modify storage pokeloot:tmp args.mode set from storage pokeloot:db chests.c$(id).mode
$execute if data storage pokeloot:db chests.c$(id).claimed[{u:$(uuid)}] run return run function pokeloot:chest/deny
function pokeloot:chest/loot with storage pokeloot:tmp args
