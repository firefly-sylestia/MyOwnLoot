scoreboard players set #result pokeloot.data 3
playsound minecraft:block.chest.close block @a[tag=pokeloot.looter] ~ ~ ~ 1 1
title @a[tag=pokeloot.looter] actionbar {"text":"The chest was empty this time. Try again!","color":"yellow"}
