scoreboard players set #result pokeloot.data 5
title @a[tag=pokeloot.looter] actionbar {"text":"This chest is misconfigured. Tell an admin.","color":"red"}
tellraw @a[tag=pokeloot.looter,tag=pokeloot.debug] {"text":"[PokeLoot debug] The loot function aborted. Test the table id with /function pokeloot:debug/roll","color":"red"}
