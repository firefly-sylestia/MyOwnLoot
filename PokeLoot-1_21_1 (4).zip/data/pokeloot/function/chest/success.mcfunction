playsound minecraft:block.chest.open block @a[tag=pokeloot.looter] ~ ~ ~ 1 1
playsound minecraft:entity.experience_orb.pickup player @a[tag=pokeloot.looter] ~ ~ ~ 0.8 1.2
particle minecraft:happy_villager ~ ~1 ~ 0.35 0.35 0.35 0 14 normal @a[tag=pokeloot.looter]
execute if data storage pokeloot:tmp args{mode:"per_player"} run title @a[tag=pokeloot.looter] actionbar {"text":"Loot rolled just for you!","color":"green"}
execute if data storage pokeloot:tmp args{mode:"shared"} run title @a[tag=pokeloot.looter] actionbar {"text":"Shared chest: every trainer gets the same reward!","color":"aqua"}
