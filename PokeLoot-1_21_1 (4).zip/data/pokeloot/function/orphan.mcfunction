# Runs as a loot chest hitbox whose chest block is gone.
execute unless score @s pokeloot.id matches 0.. run return run kill @s
data modify storage pokeloot:tmp args set value {}
execute store result storage pokeloot:tmp args.id int 1 run scoreboard players get @s pokeloot.id
function pokeloot:setup/remove_data with storage pokeloot:tmp args
kill @s
