# Macro function. Inputs: id, mode, table. Runs at an aligned block corner.
# The hitbox is a little bigger than the chest so clicks always hit it before the chest block.
summon minecraft:interaction ~0.5 ~ ~0.5 {width:1.1f,height:1.1f,response:true,Tags:["pokeloot.chest","pokeloot.new"]}
$scoreboard players set @e[type=interaction,tag=pokeloot.new,distance=..2,limit=1] pokeloot.id $(id)
tag @e[type=interaction,tag=pokeloot.new,distance=..2] remove pokeloot.new
$data modify storage pokeloot:db chests.c$(id) set value {id:$(id),mode:"$(mode)",table:"$(table)",claimed:[]}
