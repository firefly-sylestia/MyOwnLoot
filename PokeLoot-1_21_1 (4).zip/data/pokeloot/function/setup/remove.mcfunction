# Removes the nearest loot chest within 6 blocks: hitbox, registry entry and the chest block.
scoreboard players set #found pokeloot.data 0
execute as @e[type=interaction,tag=pokeloot.chest,distance=..6,sort=nearest,limit=1] at @s run function pokeloot:setup/remove_one
execute if score #found pokeloot.data matches 1 run tellraw @s {"text":"[PokeLoot] Loot chest removed.","color":"green"}
execute if score #found pokeloot.data matches 0 run tellraw @s {"text":"[PokeLoot] No loot chest within 6 blocks.","color":"red"}
