# Macro function. Inputs: mode, table.
# /function pokeloot:setup/convert {mode:"shared",table:"pokeloot:chests/starter_kit"}
# Turns the chest you are looking at (within 6 blocks) into a loot chest.
$data modify storage pokeloot:tmp cfg set value {mode:"$(mode)",table:"$(table)"}
scoreboard players set #found pokeloot.data 0
scoreboard players set #steps pokeloot.data 0
execute anchored eyes positioned ^ ^ ^ run function pokeloot:setup/ray
execute if score #found pokeloot.data matches 0 run tellraw @s {"text":"[PokeLoot] Look at a chest within 6 blocks.","color":"red"}
