# Runs as a loot chest hitbox, at it.
execute unless score @s pokeloot.id matches 0.. run return run kill @s
scoreboard players set #found pokeloot.data 1
data modify storage pokeloot:tmp args set value {}
execute store result storage pokeloot:tmp args.id int 1 run scoreboard players get @s pokeloot.id
function pokeloot:setup/remove_data with storage pokeloot:tmp args
particle minecraft:poof ~ ~0.5 ~ 0.3 0.3 0.3 0.02 10
setblock ~ ~ ~ minecraft:air
kill @s
