scoreboard players set #found pokeloot.data 1
execute align xyz run function pokeloot:setup/register_here
