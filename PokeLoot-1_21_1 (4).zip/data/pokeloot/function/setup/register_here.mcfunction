# Runs as the player, at an aligned block corner that already holds a chest. cfg must be set in pokeloot:tmp.
execute positioned ~0.5 ~ ~0.5 if entity @e[type=interaction,tag=pokeloot.chest,distance=..0.5] run return run tellraw @s {"text":"[PokeLoot] That chest is already a loot chest.","color":"red"}
scoreboard players add #last_id pokeloot.data 1
execute store result storage pokeloot:tmp cfg.id int 1 run scoreboard players get #last_id pokeloot.data
function pokeloot:setup/register with storage pokeloot:tmp cfg
tellraw @s ["",{"text":"[PokeLoot] ","color":"gold"},{"text":"Loot chest #","color":"yellow"},{"storage":"pokeloot:tmp","nbt":"cfg.id","color":"white"},{"text":" created  mode: ","color":"yellow"},{"storage":"pokeloot:tmp","nbt":"cfg.mode","color":"white"},{"text":"  table: ","color":"yellow"},{"storage":"pokeloot:tmp","nbt":"cfg.table","color":"white"}]
