# Macro function. Inputs: mode, table.
# /function pokeloot:setup/place {mode:"per_player",table:"pokeloot:chests/common"}
# Places a new loot chest two blocks in front of you, facing you.
$data modify storage pokeloot:tmp cfg set value {mode:"$(mode)",table:"$(table)"}
execute rotated ~ 0 positioned ^ ^ ^2 align xyz run function pokeloot:setup/place_at
