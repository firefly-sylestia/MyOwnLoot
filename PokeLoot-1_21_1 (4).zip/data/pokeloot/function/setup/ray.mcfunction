execute if block ~ ~ ~ minecraft:chest run return run function pokeloot:setup/ray_hit
scoreboard players add #steps pokeloot.data 1
execute if score #steps pokeloot.data matches ..60 positioned ^ ^ ^0.1 run function pokeloot:setup/ray
