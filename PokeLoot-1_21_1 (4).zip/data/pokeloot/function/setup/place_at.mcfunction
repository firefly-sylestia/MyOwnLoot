# Runs as the player, at an aligned block corner. cfg must be set in pokeloot:tmp.
# Chest faces the player: yaw 0 = south, 90 = west, 180 = north, -90 = east.
execute if entity @s[y_rotation=-45..45] run setblock ~ ~ ~ minecraft:chest[facing=north]
execute if entity @s[y_rotation=45..135] run setblock ~ ~ ~ minecraft:chest[facing=east]
execute if entity @s[y_rotation=135..180] run setblock ~ ~ ~ minecraft:chest[facing=south]
execute if entity @s[y_rotation=-180..-135] run setblock ~ ~ ~ minecraft:chest[facing=south]
execute if entity @s[y_rotation=-135..-45] run setblock ~ ~ ~ minecraft:chest[facing=west]
function pokeloot:setup/register_here
