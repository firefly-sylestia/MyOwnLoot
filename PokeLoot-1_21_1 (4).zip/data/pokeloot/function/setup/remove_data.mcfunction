# Macro function. Input: id.
$data remove storage pokeloot:db chests.c$(id)
