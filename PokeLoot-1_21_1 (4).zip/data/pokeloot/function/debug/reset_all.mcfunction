# Clears the claim list of every chest, for every player (offline players included).
scoreboard players set #i pokeloot.data 0
execute if score #last_id pokeloot.data matches 1.. run function pokeloot:debug/reset_all_loop
tellraw @s {"text":"[PokeLoot] All claims on all chests were reset.","color":"green"}
