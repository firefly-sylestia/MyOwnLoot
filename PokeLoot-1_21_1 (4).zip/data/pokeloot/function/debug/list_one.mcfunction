# Macro function. Input: id. Runs as the player.
$execute store result score #n pokeloot.data run data get storage pokeloot:db chests.c$(id).claimed
$execute if data storage pokeloot:db chests.c$(id) run tellraw @s ["",{"text":" #$(id) ","color":"aqua"},{"storage":"pokeloot:db","nbt":"chests.c$(id).mode","color":"white"},{"text":" | ","color":"gray"},{"storage":"pokeloot:db","nbt":"chests.c$(id).table","color":"white"},{"text":" | looted by ","color":"gray"},{"score":{"name":"#n","objective":"pokeloot.data"},"color":"white"},{"text":" player(s)","color":"gray"}]
