# Macro function. Input: id.
$execute if data storage pokeloot:db chests.c$(id) run data modify storage pokeloot:db chests.c$(id).claimed set value []
