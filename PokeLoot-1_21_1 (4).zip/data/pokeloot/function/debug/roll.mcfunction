# Macro function. Input: table.   /function pokeloot:debug/roll {table:"pokeloot:chests/common"}
# Rolls a table at your feet. No chest, no claim. Handy to check that a table loads and its item ids exist.
$loot spawn ~ ~ ~ loot $(table)
$tellraw @s {"text":"[PokeLoot] Rolled $(table) at your feet.","color":"green"}
