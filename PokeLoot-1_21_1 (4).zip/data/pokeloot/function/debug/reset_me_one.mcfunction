# Macro function. Inputs: id, uuid.
$data remove storage pokeloot:db chests.c$(id).claimed[{u:$(uuid)}]
