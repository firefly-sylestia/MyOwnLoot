# DANGER: deletes every loaded loot chest (block, hitbox) and the whole registry.
execute as @e[type=interaction,tag=pokeloot.chest] at @s run setblock ~ ~ ~ minecraft:air
kill @e[type=interaction,tag=pokeloot.chest]
data modify storage pokeloot:db chests set value {}
scoreboard players set #last_id pokeloot.data 0
tellraw @s {"text":"[PokeLoot] Every loot chest was removed and the registry was cleared.","color":"red"}
