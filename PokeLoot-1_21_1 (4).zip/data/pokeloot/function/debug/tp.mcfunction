# Macro function. Input: id. Only finds chests in loaded chunks.
$tp @s @e[type=interaction,tag=pokeloot.chest,scores={pokeloot.id=$(id)},limit=1]
