# Details on the nearest loot chest within 8 blocks, including whether YOU have looted it.
scoreboard players set #found pokeloot.data 0
tag @s add pokeloot.looter
execute as @e[type=interaction,tag=pokeloot.chest,distance=..8,sort=nearest,limit=1] at @s run function pokeloot:debug/info_chest
tag @s remove pokeloot.looter
execute if score #found pokeloot.data matches 0 run tellraw @s {"text":"[PokeLoot] No loot chest within 8 blocks.","color":"red"}
