# Macro function. Inputs: id, uuid.
$execute store result score #n pokeloot.data run data get storage pokeloot:db chests.c$(id).claimed
$tellraw @a[tag=pokeloot.looter] ["",{"text":"[PokeLoot] ","color":"gold"},{"text":"Chest #$(id)  mode: ","color":"yellow"},{"storage":"pokeloot:db","nbt":"chests.c$(id).mode","color":"white"},{"text":"  table: ","color":"yellow"},{"storage":"pokeloot:db","nbt":"chests.c$(id).table","color":"white"},{"text":"  looted by: ","color":"yellow"},{"score":{"name":"#n","objective":"pokeloot.data"},"color":"white"}]
$execute if data storage pokeloot:db chests.c$(id).claimed[{u:$(uuid)}] run tellraw @a[tag=pokeloot.looter] {"text":"[PokeLoot] You have already looted this chest.","color":"red"}
$execute unless data storage pokeloot:db chests.c$(id).claimed[{u:$(uuid)}] run tellraw @a[tag=pokeloot.looter] {"text":"[PokeLoot] You have not looted this chest yet.","color":"green"}
