# Macro function. Input: id.   /function pokeloot:debug/reset_chest {id:1}
$execute unless data storage pokeloot:db chests.c$(id) run return run tellraw @s {"text":"[PokeLoot] No chest with id $(id).","color":"red"}
$data modify storage pokeloot:db chests.c$(id).claimed set value []
$tellraw @s {"text":"[PokeLoot] Claims reset for chest #$(id).","color":"green"}
