# Runs as a loot chest hitbox. The asking player carries the tag pokeloot.looter.
execute unless score @s pokeloot.id matches 0.. run return run tellraw @a[tag=pokeloot.looter] {"text":"[PokeLoot] That hitbox has no id. Use setup/remove.","color":"red"}
scoreboard players set #found pokeloot.data 1
data modify storage pokeloot:tmp args set value {}
execute store result storage pokeloot:tmp args.id int 1 run scoreboard players get @s pokeloot.id
data modify storage pokeloot:tmp args.uuid set from entity @a[tag=pokeloot.looter,limit=1] UUID
function pokeloot:debug/info_print with storage pokeloot:tmp args
