scoreboard players add #i pokeloot.data 1
execute store result storage pokeloot:tmp args.id int 1 run scoreboard players get #i pokeloot.data
function pokeloot:debug/reset_me_one with storage pokeloot:tmp args
execute if score #i pokeloot.data < #last_id pokeloot.data run function pokeloot:debug/reset_me_loop
