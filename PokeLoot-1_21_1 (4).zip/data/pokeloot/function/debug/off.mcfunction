tag @s remove pokeloot.debug
tellraw @s {"text":"[PokeLoot] Debug messages OFF.","color":"yellow"}
