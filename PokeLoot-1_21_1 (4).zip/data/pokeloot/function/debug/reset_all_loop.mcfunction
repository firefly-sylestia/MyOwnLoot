scoreboard players add #i pokeloot.data 1
data modify storage pokeloot:tmp args set value {}
execute store result storage pokeloot:tmp args.id int 1 run scoreboard players get #i pokeloot.data
function pokeloot:debug/reset_one_quiet with storage pokeloot:tmp args
execute if score #i pokeloot.data < #last_id pokeloot.data run function pokeloot:debug/reset_all_loop
