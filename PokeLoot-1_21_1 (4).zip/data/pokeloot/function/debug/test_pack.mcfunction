# Spawns four test chests in a row, three blocks in front of you.
# Left to right: per-player vanilla, shared vanilla, per-player Cobblemon, shared Cobblemon.
data modify storage pokeloot:tmp cfg set value {mode:"per_player",table:"pokeloot:chests/debug_random"}
execute rotated ~ 0 positioned ^-3 ^ ^3 align xyz run function pokeloot:setup/place_at
data modify storage pokeloot:tmp cfg set value {mode:"shared",table:"pokeloot:chests/debug_fixed"}
execute rotated ~ 0 positioned ^-1 ^ ^3 align xyz run function pokeloot:setup/place_at
data modify storage pokeloot:tmp cfg set value {mode:"per_player",table:"pokeloot:chests/common"}
execute rotated ~ 0 positioned ^1 ^ ^3 align xyz run function pokeloot:setup/place_at
data modify storage pokeloot:tmp cfg set value {mode:"shared",table:"pokeloot:chests/starter_kit"}
execute rotated ~ 0 positioned ^3 ^ ^3 align xyz run function pokeloot:setup/place_at
tellraw @s {"text":"[PokeLoot] Test chests placed. Right-click each one, then try debug/reset_me and open them again.","color":"gold"}
