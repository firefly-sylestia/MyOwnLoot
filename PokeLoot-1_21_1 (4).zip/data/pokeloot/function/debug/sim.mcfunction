# Macro function. Input: name.   /function pokeloot:debug/sim {name:"Steve"}
# Pretends the named online player right-clicked the loot chest nearest to YOU.
$tag @a[name=$(name),limit=1] add pokeloot.looter
execute as @e[type=interaction,tag=pokeloot.chest,distance=..8,sort=nearest,limit=1] at @s run function pokeloot:chest/handle
tag @a remove pokeloot.looter
