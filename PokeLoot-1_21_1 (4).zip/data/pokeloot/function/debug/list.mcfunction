tellraw @s {"text":"[PokeLoot] Registered loot chests:","color":"gold"}
scoreboard players set #i pokeloot.data 0
execute if score #last_id pokeloot.data matches 1.. run function pokeloot:debug/list_loop
