execute if entity @s[tag=pokeloot.debug] run return run function pokeloot:debug/off
tag @s add pokeloot.debug
tellraw @s {"text":"[PokeLoot] Debug messages ON. You will see a line every time you click a loot chest.","color":"green"}
