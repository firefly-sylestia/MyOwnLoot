# Removes YOUR claim from every chest so you can test again.
data modify storage pokeloot:tmp args set value {}
data modify storage pokeloot:tmp args.uuid set from entity @s UUID
scoreboard players set #i pokeloot.data 0
execute if score #last_id pokeloot.data matches 1.. run function pokeloot:debug/reset_me_loop
tellraw @s {"text":"[PokeLoot] Your claims were reset. You can loot every chest again.","color":"green"}
