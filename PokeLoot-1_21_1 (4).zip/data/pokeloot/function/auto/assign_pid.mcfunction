# Gives a player a permanent small number used as a key in storage.
scoreboard players add #next_pid pokeloot.data 1
scoreboard players operation @s pokeloot.pid = #next_pid pokeloot.data
