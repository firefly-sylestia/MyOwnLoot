# Macro. Inputs: pid, key, dim, x, y, z. Runs as the player.
$execute in $(dim) positioned $(x) $(y) $(z) if data block ~ ~ ~ Items if data storage pokeloot:auto reg."$(key)"{kind:1} run data modify storage pokeloot:auto reg."$(key)".players.p$(pid) set from block ~ ~ ~ Items
$execute in $(dim) positioned $(x) $(y) $(z) if data block ~ ~ ~ storageWrapper.contents if data storage pokeloot:auto reg."$(key)"{kind:2} run data modify storage pokeloot:auto reg."$(key)".players.p$(pid) set from block ~ ~ ~ storageWrapper.contents
$execute in $(dim) positioned $(x) $(y) $(z) unless entity @s[distance=..16] run function pokeloot:auto/unattach with storage pokeloot:auto att.p$(pid)
