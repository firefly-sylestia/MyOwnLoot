# Macro. Input: key.
$execute if data storage pokeloot:auto reg."$(key)" run return 0
$execute unless data block ~ ~ ~ LootTable run return 0
$data modify storage pokeloot:auto reg."$(key)" set value {viewer:0,players:{},kind:1}
data modify storage pokeloot:tmp rt set value {}
data modify storage pokeloot:tmp rt.table set from block ~ ~ ~ LootTable
function pokeloot:auto/roll with storage pokeloot:tmp rt
$function pokeloot:auto/store_pristine with storage pokeloot:tmp k
tellraw @s [{"text":"[PokeLoot] tracking loot container, table: ","color":"gray"},{"storage":"pokeloot:tmp","nbt":"rt.table","color":"white"}]
