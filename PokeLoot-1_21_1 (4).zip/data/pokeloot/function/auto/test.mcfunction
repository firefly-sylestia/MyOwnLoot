# Places a fresh chest with a vanilla loot table two blocks in front of you, to test auto mode.
execute rotated ~ 0 positioned ^ ^ ^2 align xyz run setblock ~ ~ ~ minecraft:chest[facing=north]{LootTable:"minecraft:chests/simple_dungeon"} replace
tellraw @s {"text":"[PokeLoot] Test chest placed. Look at it, then open it with two different players.","color":"yellow"}
