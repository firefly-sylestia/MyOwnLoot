scoreboard players set #pz pokeloot.data 0
function pokeloot:auto/protect_z
scoreboard players add #py pokeloot.data 1
execute if score #py pokeloot.data matches ..20 positioned ~ ~1 ~ run function pokeloot:auto/protect_y
