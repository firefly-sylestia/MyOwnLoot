scoreboard players set #py pokeloot.data 0
function pokeloot:auto/protect_y
scoreboard players add #px pokeloot.data 1
execute if score #px pokeloot.data matches ..20 positioned ~1 ~ ~ run function pokeloot:auto/protect_x
