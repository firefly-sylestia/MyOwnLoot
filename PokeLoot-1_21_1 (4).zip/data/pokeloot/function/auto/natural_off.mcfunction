scoreboard players set #natural pokeloot.data 0
tellraw @s {"text":"[PokeLoot] Natural barrel and gilded chest tracking is OFF.","color":"yellow"}
