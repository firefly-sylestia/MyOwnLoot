# Marks every barrel and gilded chest within 10 blocks of you as player owned (never tracked as loot).
# Run it at player bases and storage rooms that existed before this pack.
scoreboard players set #prot pokeloot.data 0
scoreboard players set #px pokeloot.data 0
execute positioned ~-10 ~-10 ~-10 run function pokeloot:auto/protect_x
tellraw @s [{"text":"[PokeLoot] Protected containers: ","color":"green"},{"score":{"name":"#prot","objective":"pokeloot.data"},"color":"white"}]
