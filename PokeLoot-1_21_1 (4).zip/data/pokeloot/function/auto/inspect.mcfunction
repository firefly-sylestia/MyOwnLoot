# /function pokeloot:auto/inspect  -- look at a container (within ~6 blocks) and run this. Prints what auto mode sees.
scoreboard players set #steps pokeloot.data 0
execute anchored eyes positioned ^ ^ ^ run function pokeloot:auto/inspect_ray
