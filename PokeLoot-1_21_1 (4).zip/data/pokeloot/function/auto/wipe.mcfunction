# Forgets every tracked natural chest and every saved per-player copy.
data modify storage pokeloot:auto reg set value {}
data modify storage pokeloot:auto att set value {}
tag @a remove pokeloot.att
tellraw @s {"text":"[PokeLoot] Auto-mode registry wiped.","color":"green"}
