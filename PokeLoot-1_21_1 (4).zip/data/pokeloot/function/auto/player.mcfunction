# Runs as the player, at the player.
execute unless score @s pokeloot.pid matches 1.. run function pokeloot:auto/assign_pid
# Look along the crosshair: any unopened loot container gets registered before it can be opened.
scoreboard players set #steps pokeloot.data 0
execute anchored eyes positioned ^ ^ ^ run function pokeloot:auto/ray
# Keep saving what this player leaves in the chest they last opened.
execute if entity @s[tag=pokeloot.att] store result storage pokeloot:tmp s.pid int 1 run scoreboard players get @s pokeloot.pid
execute if entity @s[tag=pokeloot.att] run function pokeloot:auto/snap_check with storage pokeloot:tmp s
