# Macro. Input: pid. Runs as the player.
$execute unless data storage pokeloot:auto att.p$(pid) run return run tag @s remove pokeloot.att
$function pokeloot:auto/snap with storage pokeloot:auto att.p$(pid)
