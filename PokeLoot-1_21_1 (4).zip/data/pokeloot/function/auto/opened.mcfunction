# Advancement reward. Runs as a player who just used a block.
advancement revoke @s only pokeloot:auto_open
scoreboard players set #steps pokeloot.data 0
execute anchored eyes positioned ^ ^ ^ run function pokeloot:auto/open_ray
