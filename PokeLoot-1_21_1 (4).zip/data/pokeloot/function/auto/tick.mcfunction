# Every tick, for every player.
execute as @a[gamemode=!spectator] at @s run function pokeloot:auto/player
