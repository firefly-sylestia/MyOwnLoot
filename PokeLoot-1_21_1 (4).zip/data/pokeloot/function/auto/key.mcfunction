# Runs as a player, at a point inside a block. Builds storage pokeloot:tmp k = {dim,x,y,z,key}.
data modify storage pokeloot:tmp k set value {}
execute align xyz run summon minecraft:marker ~ ~ ~ {Tags:["pokeloot.key"]}
execute store result storage pokeloot:tmp k.x int 1 run data get entity @e[type=minecraft:marker,tag=pokeloot.key,limit=1] Pos[0]
execute store result storage pokeloot:tmp k.y int 1 run data get entity @e[type=minecraft:marker,tag=pokeloot.key,limit=1] Pos[1]
execute store result storage pokeloot:tmp k.z int 1 run data get entity @e[type=minecraft:marker,tag=pokeloot.key,limit=1] Pos[2]
kill @e[type=minecraft:marker,tag=pokeloot.key]
data modify storage pokeloot:tmp k.dim set from entity @s Dimension
function pokeloot:auto/key_m with storage pokeloot:tmp k
