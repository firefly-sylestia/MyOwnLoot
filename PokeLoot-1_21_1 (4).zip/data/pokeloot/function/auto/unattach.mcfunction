# Macro. Input: pid. Runs as the player.
tag @s remove pokeloot.att
$data remove storage pokeloot:auto att.p$(pid)
