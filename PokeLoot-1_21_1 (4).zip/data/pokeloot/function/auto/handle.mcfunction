# Macro. Inputs: key, pid, dim, x, y, z. Runs as the player, at the container being opened.
$execute unless data storage pokeloot:auto reg."$(key)" run return run function pokeloot:auto/untracked
$data modify storage pokeloot:tmp d set value {key:"$(key)"}
$data modify storage pokeloot:tmp d.viewer set from storage pokeloot:auto reg."$(key)".viewer
$execute unless data storage pokeloot:auto reg."$(key)"{viewer:$(pid)} run function pokeloot:auto/detach with storage pokeloot:tmp d
$execute if data storage pokeloot:auto reg."$(key)".players.p$(pid) if data storage pokeloot:auto reg."$(key)"{kind:1} run data modify block ~ ~ ~ Items set from storage pokeloot:auto reg."$(key)".players.p$(pid)
$execute if data storage pokeloot:auto reg."$(key)".players.p$(pid) if data storage pokeloot:auto reg."$(key)"{kind:2} run data modify block ~ ~ ~ storageWrapper.contents set from storage pokeloot:auto reg."$(key)".players.p$(pid)
$execute unless data storage pokeloot:auto reg."$(key)".players.p$(pid) if data storage pokeloot:auto reg."$(key)"{kind:1} run data modify block ~ ~ ~ Items set from storage pokeloot:auto reg."$(key)".pristine
$execute unless data storage pokeloot:auto reg."$(key)".players.p$(pid) if data storage pokeloot:auto reg."$(key)"{kind:2} run data modify block ~ ~ ~ storageWrapper.contents set from storage pokeloot:auto reg."$(key)".pristine
$data modify storage pokeloot:auto reg."$(key)".viewer set value $(pid)
$data modify storage pokeloot:auto att.p$(pid) set value {pid:$(pid),key:"$(key)",dim:"$(dim)",x:$(x),y:$(y),z:$(z)}
tag @s add pokeloot.att
