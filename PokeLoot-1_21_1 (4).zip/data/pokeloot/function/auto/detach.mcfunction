# Macro. Inputs: key, viewer. Stops the old viewer's saving, but only if they are still attached to this same chest.
$execute if data storage pokeloot:auto att.p$(viewer){key:"$(key)"} run tag @a[scores={pokeloot.pid=$(viewer)}] remove pokeloot.att
$execute if data storage pokeloot:auto att.p$(viewer){key:"$(key)"} run data remove storage pokeloot:auto att.p$(viewer)
