execute if block ~ ~ ~ #pokeloot:natural_types run return run function pokeloot:auto/placed_hit
execute unless block ~ ~ ~ #pokeloot:see_through run return 0
scoreboard players add #steps pokeloot.data 1
execute if score #steps pokeloot.data matches ..30 positioned ^ ^ ^0.2 run function pokeloot:auto/placed_ray
