# Advancement reward. A player placed a barrel or gilded chest: remember it as player owned.
advancement revoke @s only pokeloot:auto_placed
scoreboard players set #steps pokeloot.data 0
execute anchored eyes positioned ^ ^ ^ run function pokeloot:auto/placed_ray
