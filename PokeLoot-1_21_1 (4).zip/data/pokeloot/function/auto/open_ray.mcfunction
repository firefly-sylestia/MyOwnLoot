# Finds the first solid block on the crosshair, which is the one that was used.
execute unless block ~ ~ ~ #pokeloot:see_through run return run function pokeloot:auto/open_hit
scoreboard players add #steps pokeloot.data 1
execute if score #steps pokeloot.data matches ..30 positioned ^ ^ ^0.2 run function pokeloot:auto/open_ray
