# Steps along the crosshair (0.2 blocks per step, about 5 blocks).
execute if data block ~ ~ ~ LootTable run return run function pokeloot:auto/register
execute unless block ~ ~ ~ #pokeloot:see_through run return 0
scoreboard players add #steps pokeloot.data 1
execute if score #steps pokeloot.data matches ..26 positioned ^ ^ ^0.2 run function pokeloot:auto/ray
