function pokeloot:auto/key
function pokeloot:auto/own_m with storage pokeloot:tmp k
