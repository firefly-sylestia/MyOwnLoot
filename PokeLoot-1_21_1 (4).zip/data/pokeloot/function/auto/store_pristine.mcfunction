# Macro. Input: key. Saves the chest's current contents as its fixed loot.
$execute if data storage pokeloot:auto reg."$(key)"{kind:2} run data modify storage pokeloot:auto reg."$(key)".pristine set from block ~ ~ ~ storageWrapper.contents
$execute if data storage pokeloot:auto reg."$(key)"{kind:1} run data modify storage pokeloot:auto reg."$(key)".pristine set from block ~ ~ ~ Items
