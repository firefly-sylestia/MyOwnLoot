# Runs as a player, at a container that still has a LootTable. Rolls that table once, for everyone.
execute if block ~ ~ ~ #pokeloot:ignore run return 0
function pokeloot:auto/key
function pokeloot:auto/register_m with storage pokeloot:tmp k
