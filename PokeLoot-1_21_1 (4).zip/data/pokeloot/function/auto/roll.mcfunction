# Macro. Input: table. Fills the container once from its own loot table, then removes the table so vanilla never re-rolls it.
$loot replace block ~ ~ ~ container.0 27 loot $(table)
data remove block ~ ~ ~ LootTable
data remove block ~ ~ ~ LootTableSeed
