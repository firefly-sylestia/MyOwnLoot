# Runs as the player, at the block being looked at.
tellraw @s {"text":"[PokeLoot] raw block data:","color":"yellow"}
data get block ~ ~ ~
execute if data block ~ ~ ~ LootTable run tellraw @s {"text":"  LootTable present: will be rolled and tracked on look.","color":"green"}
execute if data block ~ ~ ~ Items run tellraw @s {"text":"  Items present (vanilla contents).","color":"gray"}
execute if data block ~ ~ ~ storageWrapper.contents run tellraw @s {"text":"  Sophisticated Storage contents present.","color":"gray"}
execute unless block ~ ~ ~ #pokeloot:natural_types run tellraw @s {"text":"  Block is not in the natural list.","color":"red"}
function pokeloot:auto/key
function pokeloot:auto/inspect_reg with storage pokeloot:tmp k
