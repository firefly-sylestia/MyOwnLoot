# Runs as a player who opened a container auto mode did not know about.
execute if entity @s[tag=pokeloot.debug] run tellraw @s {"text":"[PokeLoot] you opened a container that was never tracked (no LootTable was seen before it opened). It behaves like a normal chest.","color":"gray"}
