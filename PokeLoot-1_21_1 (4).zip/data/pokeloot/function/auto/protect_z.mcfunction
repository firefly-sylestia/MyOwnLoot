execute if block ~ ~ ~ #pokeloot:natural_types run function pokeloot:auto/protect_one
scoreboard players add #pz pokeloot.data 1
execute if score #pz pokeloot.data matches ..20 positioned ~ ~ ~1 run function pokeloot:auto/protect_z
