# Runs as the player, at the block that was used.
execute if data block ~ ~ ~ LootTable run return 0
function pokeloot:auto/key
execute store result storage pokeloot:tmp k.pid int 1 run scoreboard players get @s pokeloot.pid
function pokeloot:auto/pre_check
function pokeloot:auto/handle with storage pokeloot:tmp k
