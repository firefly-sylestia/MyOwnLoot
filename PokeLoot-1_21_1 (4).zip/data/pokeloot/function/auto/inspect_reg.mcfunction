# Macro. Input: key.
$execute if data storage pokeloot:auto reg."$(key)" run tellraw @s {"text":"  Registered in auto mode.","color":"green"}
$execute unless data storage pokeloot:auto reg."$(key)" run tellraw @s {"text":"  Not registered in auto mode.","color":"red"}
