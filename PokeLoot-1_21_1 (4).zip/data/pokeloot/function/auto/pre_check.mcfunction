# Runs as a player, at a container the player is opening. Registers natural, pre-filled containers.
execute unless score #natural pokeloot.data matches 1 run return 0
execute unless block ~ ~ ~ #pokeloot:natural_types run return 0
execute if data block ~ ~ ~ LootTable run return 0
function pokeloot:auto/key
function pokeloot:auto/pre_m with storage pokeloot:tmp k
