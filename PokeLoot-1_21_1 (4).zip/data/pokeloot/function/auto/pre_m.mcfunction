# Macro. Input: key. Runs as the player, at the container.
$execute if data storage pokeloot:auto owned."$(key)" run return 0
$execute if data storage pokeloot:auto reg."$(key)" run return 0
$execute unless data block ~ ~ ~ Items unless data block ~ ~ ~ storageWrapper.contents run return 0
$data modify storage pokeloot:auto reg."$(key)" set value {viewer:0,players:{}}
$execute if data block ~ ~ ~ storageWrapper.contents run data modify storage pokeloot:auto reg."$(key)".kind set value 2
$execute unless data block ~ ~ ~ storageWrapper.contents run data modify storage pokeloot:auto reg."$(key)".kind set value 1
$function pokeloot:auto/store_pristine with storage pokeloot:tmp k
