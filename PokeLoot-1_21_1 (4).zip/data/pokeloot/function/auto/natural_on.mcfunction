scoreboard players set #natural pokeloot.data 1
tellraw @s {"text":"[PokeLoot] Natural container tracking is ON.","color":"green"}
