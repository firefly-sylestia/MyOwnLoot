# Macro. Inputs: dim, x, y, z.
$data modify storage pokeloot:tmp k.key set value "$(dim)|$(x)|$(y)|$(z)"
