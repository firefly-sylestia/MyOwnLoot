# Macro. Input: key. Marks a container as player owned and forgets any natural entry at that spot.
$data modify storage pokeloot:auto owned."$(key)" set value 1b
$data remove storage pokeloot:auto reg."$(key)"
