# Advancement reward. Runs as the player who right-clicked a loot chest hitbox.
advancement revoke @s only pokeloot:interact_chest
tag @s add pokeloot.looter
execute as @e[type=interaction,tag=pokeloot.chest,distance=..8,nbt={interaction:{}},sort=nearest,limit=1] at @s run function pokeloot:chest/handle
tag @s remove pokeloot.looter
