# PokeLoot: runs on server start and on /reload.
scoreboard objectives add pokeloot.data dummy
scoreboard objectives add pokeloot.id dummy
execute unless data storage pokeloot:db chests run data modify storage pokeloot:db chests set value {}
execute unless score #last_id pokeloot.data matches 0.. run scoreboard players set #last_id pokeloot.data 0
schedule function pokeloot:loop 20t replace
# Auto mode (natural and modded loot chests)
scoreboard objectives add pokeloot.pid dummy
execute unless score #next_pid pokeloot.data matches 0.. run scoreboard players set #next_pid pokeloot.data 0
execute unless data storage pokeloot:auto reg run data modify storage pokeloot:auto reg set value {}
execute unless data storage pokeloot:auto att run data modify storage pokeloot:auto att set value {}
execute unless score #natural pokeloot.data matches 0.. run scoreboard players set #natural pokeloot.data 1
execute unless data storage pokeloot:auto owned run data modify storage pokeloot:auto owned set value {}
