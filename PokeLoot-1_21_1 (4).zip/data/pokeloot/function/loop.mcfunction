# Once per second: if a loot chest block was destroyed, clean up its hitbox and registry entry.
schedule function pokeloot:loop 20t replace
execute as @e[type=interaction,tag=pokeloot.chest] at @s if loaded ~ ~ ~ unless block ~ ~ ~ minecraft:chest run function pokeloot:orphan
