# PokeLoot (Minecraft 1.21.1, Cobblemon)

Loot chests for multiplayer servers. Every chest is one of two kinds:

* **per_player**: each player rolls the chest's loot table for themselves, so players get different loot.
* **shared**: the chest points at a fixed table with no randomness, so every player gets the same items.

In both kinds a player can open a given chest **one time**. After that they get "You already looted this chest."

## Install

1. Put `PokeLoot-1.21.1.zip` in `<world>/datapacks/` (do not unzip it).
2. Run `/reload` or restart the server.
3. Cobblemon must be installed on the server for the Cobblemon tables. The vanilla debug tables work without it.

## 60 second test

1. `/function pokeloot:debug/toggle` turns on live debug lines for you.
2. `/function pokeloot:debug/test_pack` spawns 4 chests in front of you.
3. Right-click each chest. Items pop out at your feet and only you can pick them up.
4. Right-click again: "already looted". `debug/info` shows the same.
5. `/function pokeloot:debug/reset_me` and try again. With a second player, check that the per_player chests roll different loot and the shared chests give identical loot.
6. `/function pokeloot:debug/sim {name:"OtherPlayer"}` fakes another player opening the chest nearest to you.

## Making real chests

```
/function pokeloot:setup/place   {mode:"per_player",table:"pokeloot:chests/common"}
/function pokeloot:setup/place   {mode:"shared",table:"pokeloot:chests/starter_kit"}
/function pokeloot:setup/convert {mode:"per_player",table:"pokeloot:chests/rare"}
/function pokeloot:setup/remove
```

* `place` puts a new chest two blocks in front of you, facing you.
* `convert` turns the chest you are looking at into a loot chest, so you can build it where you like first.
* `remove` deletes the nearest loot chest within 6 blocks.

## Included loot tables

| Table | Kind | Contents |
| --- | --- | --- |
| `pokeloot:chests/common` | random | Poke Balls, potions, Great Balls, a little Revive and candy |
| `pokeloot:chests/rare` | random | Great/Ultra Balls, potions, Revives, candy, small Rare Candy and evolution stone chance |
| `pokeloot:chests/epic` | random | Ultra Balls, Max items, Rare Candy, stones, tiny Master Ball chance |
| `pokeloot:chests/starter_kit` | fixed | 10 Poke Balls, 3 Potions, 1 Revive, 3 small Exp Candy |
| `pokeloot:chests/debug_random` | random | vanilla items only |
| `pokeloot:chests/debug_fixed` | fixed | vanilla items only |

To add your own, drop a loot table JSON in `data/pokeloot/loot_table/chests/` and point a chest at it. For a **shared** chest, write the table with one pool per item and no weights, so nothing is random. Check any table with `/function pokeloot:debug/roll {table:"pokeloot:chests/yourtable"}`. If a Cobblemon item id is wrong, the table fails to load and the log names the bad id.

## How it works

* A chest is a normal chest block plus an invisible `interaction` entity slightly larger than the block. The entity catches the click, so the vanilla chest GUI never opens and players cannot break the block by hand.
* A `player_interacted_with_entity` advancement fires a function for the clicking player. It looks up the chest in `storage pokeloot:db` and checks that player's UUID against the chest's claim list.
* Loot is rolled with `loot spawn` as the player at their feet, and the drops are locked to that player (`Owner`). A full inventory cannot lose items, they just wait on the ground for 5 minutes.
* A roll that produces nothing does not count as a claim.
* Every second a small loop removes the hitbox and registry entry of any loot chest whose block was destroyed (explosions, pistons).

## Notes

* Admin commands need permission level 2 (`/function`). Players need no permissions to loot.
* `shared` and `per_player` are stored on the chest and shown in messages. The behaviour difference comes from the table you pick.
* `debug/tp` and `debug/wipe` only see loaded chunks.
* Claims are stored by player UUID, so they survive renames, relogs and restarts. `debug/reset_chest` and `debug/reset_all` also clear offline players.

## Auto mode: natural and modded loot chests

Works with no setup. Any chest, barrel or shulker box that still has a loot table when a player looks at it (village, dungeon, Cobblemon gilded chests, other mods) is tracked automatically.

* The chest opens as the normal chest GUI. The first opening lets the mod roll its own loot table, and that result becomes the chest's fixed loot.
* Every other player who opens it sees that same loot. Each player has their own copy, so taking items only affects them, and what they leave behind is waiting next time.
* `pokeloot:auto/test` places a test chest. `pokeloot:auto/wipe` forgets all tracked chests. With `debug/toggle` on, you get a message when a chest is tracked, with its table id.

Limits: a chest has to be looked at for one tick before it is first opened (normal play always does this). Two players should not have the same chest open at the same moment. Chest minecarts and boats are not covered. A double chest only swaps the half you clicked. If a tracked chest is broken and another chest is built at the exact same spot, it stays a loot chest. Check that your gilded chest works with `debug/toggle`, then look at one: you should get the "tracking" message.

If a container from some mod is not tracked, look at it before opening and run `/function pokeloot:auto/inspect`. It prints the block id, whether it still has a loot table, and whether auto mode registered it.

### Pre-filled barrels and gilded chests (no loot table)

Structure barrels and gilded chests are often filled when the structure generates, so they carry no loot table. Auto mode can still treat them as loot chests by block type (`#pokeloot:natural_types`): only the block types that the Cobbleverse structures actually fill, listed in the tag file. Anything a player places is marked as player owned and never tracked. Placements are remembered automatically from now on.

Blocks placed before this pack cannot be told apart, so set up in this order:

1. Stand in each base or storage room and run `/function pokeloot:auto/protect` (covers 10 blocks around you).
2. Natural tracking is on by default. `/function pokeloot:auto/natural_off` turns it off.

The contents at the first opening become the fixed loot for everyone. `/function pokeloot:auto/natural_off` turns it off again.



### Block types and structures covered

Vanilla: `minecraft:barrel`, `minecraft:chest`, `minecraft:trapped_chest`, `minecraft:yellow_shulker_box`.
Cobblemon gilded chests: `gilded_chest`, `blue`, `black`, `yellow`, `white`, `green`, `pink`. Gimmighoul chests are excluded on purpose.
Carved Wood: acacia_barrel, acacia_chest, cherry_chest, crimson_barrel, dark_oak_barrel, jungle_barrel, mangrove_barrel, oak_barrel, trapped_dark_oak_chest, warped_barrel.

Structures: Kanto, Johto, Hoenn, and Sinnoh league buildings, Koga, Misty, Lt. Surge, Walter, Team Rocket towers, Mew, Secret Garden, Sky Pillar, Bell Tower, Rocket Radio Tower, Sandra, Corrado, Crescent Isle, Eterna Building, Fannie, Ferruccio, Fullmoon Island, Marzia, Manaphy, Split Decision Temple, Team Galactic HQ, Ash, and the Articuno, Moltres, and Zapdos legendary chambers.

Structure chests that already have a loot table (for example Spear Pillar and Wind Plant) use the normal path, so they are not part of this list.

Not covered: Sophisticated Storage barrels (their contents are not stored in the structure's chest data) and Gimmighoul chests.
